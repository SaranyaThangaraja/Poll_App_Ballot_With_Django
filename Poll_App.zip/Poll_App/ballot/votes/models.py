from django.db import models

# Create your models here.

class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')

    def __str__(self):
        return self.question_text

class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def __str__(self):
        return self.choice_text

# After model created,python3 manage.py makemigrations votes
# Then,python3 manage.py migrate
# python manage.py shell
# from votes.models import Question, Choice
# Question.objects.all()
# from django.utils import timezone
# q=Question(question_text="What is your favorite Python Framework?", pub_date=timezone.now())
# q.save()
# q.question_text
# q.pub_date
# Question.objects.all() OR Question.objects.filter(id=1) OR Question.objects.get(pk=1)
# q.choice_set.create(choice_text="Django", votes=0)
# q.choice_set.all()
# quit()

# python3 manage.py createsuperuser

# Admin:-
# import model and its options to display
# setup the questions and choices using ChoiceInline, QuestionAdmin, inlines

# Views:-
# import model and its options to display

# URLs in app(votes)

# templates created and added the templates path inside settings.py

# HTML files updated

# adjusted the views